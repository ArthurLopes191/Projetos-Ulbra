const PedidoSorvete = require("./pedido/pedido")

let pedidoSorvete = new PedidoSorvete("morango", 7, 23.00, 9)

console.log(pedidoSorvete)